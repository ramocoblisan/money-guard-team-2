export const selectBalance = state => state.auth.user.balance;
