export const selectStatisticsData = (state) => state.statistics.statisticsData;
export const selectCategories = (state) => state.statistics.categories;