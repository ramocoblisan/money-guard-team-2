export const selectorCategoriesTr = (state) => state.categories_transactions.categories;
export const selectorIsLoading = (state) => state.categories_transactions.isLoading;
export const selectorError = (state) => state.categories_transactions.error;