export const selectorCurrency = state => state.currency.currency;
export const selectorIsLoading = state => state.currency.isLoading;
export const selectorError = state => state.currency.error;
